library(blocking)
library(data.table)
library(ragnar)

data("foreigners")
setDT(foreigners)

foreigners[, txt:=paste(fname, sname, surname, date, country, region)]
foreigners_emb <- embed_ollama(
  data.frame(text = foreigners$txt),
  base_url = "http://localhost:11434",
  model = "embeddinggemma",
  batch_size = 10L)
foreigners[, count:=.N, true_id]
foreigners[, row_id:=1:.N]
foreigners_sub <- foreigners[, head(.SD, 1), true_id]
foreigners_query <- foreigners[!row_id %in% foreigners_sub$row_id]

foreigners_matches <- merge(x = foreigners_sub[, .(x=1:.N, true_id)],
                            y = foreigners_query[, .(y = 1:.N, true_id)],
                            by = "true_id")
foreigners_matches[, block:=as.numeric(as.factor(true_id))]

set.seed(2026)
foreigners_shingles_result <- blocking(x = foreigners_sub$txt,
                                       y = foreigners_query$txt,
                                       true_blocks = foreigners_matches[, .(x, y, block)],
                                       n_threads = 8,
                                       seed = 2026)

foreigners_shingles_result3 <- blocking(x = foreigners_sub$txt,
                                        y = foreigners_query$txt,
                                        true_blocks = foreigners_matches[, .(x, y, block)],
                                        n_threads = 8,
                                        seed = 2026,
                                        control_txt = controls_txt(n_shingles = 3L))

foreigners_sub_emb <- foreigners_emb$embedding[foreigners_sub$row_id, ]
foreigners_query_emb <- foreigners_emb$embedding[foreigners_query$row_id, ]

colnames(foreigners_sub_emb) <- colnames(foreigners_query_emb) <-
  paste0("v", 1:ncol(foreigners_query_emb))

foreigners_emb_result <- blocking(x = foreigners_sub_emb,
                                  y = foreigners_query_emb,
                                  true_blocks = foreigners_matches[, .(x, y, block)],
                                  n_threads = 8,
                                  seed = 2026)

foreigners_shingles_result
foreigners_shingles_result3
foreigners_emb_result
