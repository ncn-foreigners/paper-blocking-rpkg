library(blocking)
library(data.table)
library(knitr)

data("RLdata500")
setDT(RLdata500)
RLdata500[, id_count :=.N, ent_id]
RLdata500[, txt:=tolower(paste0(fname_c1,fname_c2,lname_c1,lname_c2,by,
                                sprintf("%02d", bm),sprintf("%02d", bd)))]

n_pairs_true <- sum(table(RLdata500$ent_id) * (table(RLdata500$ent_id) - 1) / 2)
n_pairs_all <- NROW(RLdata500) * (NROW(RLdata500) - 1) / 2

set.seed(2025)
true_blocks <- RLdata500[, c("rec_id", "ent_id"), with = FALSE]
setnames(true_blocks, old = c("rec_id", "ent_id"), c("x", "block"))
eval_metrics <- list()
ann <- c("nnd", "hnsw", "annoy", "lsh", "kd")
for (algorithm in ann) {
  res <- blocking(
    x = RLdata500$txt,
    ann = algorithm,
    true_blocks = true_blocks)
  eval_metrics[[algorithm]] <- res$metrics
  cat("\n=== Confusion Matrix:", algorithm, "===\n")
  print(res$confusion)
}

blocks_klsh_10 <- klsh::klsh(
  r.set = RLdata500[, c("fname_c1", "fname_c2", "lname_c1",
                        "lname_c2", "by", "bm", "bd")],
  p = 20, num.blocks = 10, k = 2)

klsh_10_metrics <- klsh::confusion.from.blocking(
  blocking = blocks_klsh_10,
  true_ids = RLdata500$ent_id)[-1]

c_rec <- klsh_10_metrics$recall
c_prec <- klsh_10_metrics$precision

val_tp <- round(c_rec * n_pairs_true)
val_fn <- n_pairs_true - val_tp
val_fp <- if (c_prec == 0) 0 else round(val_tp * (1/c_prec - 1))
val_tn <- n_pairs_all - (val_tp + val_fp + val_fn)

cat("\n=== Confusion Matrix: klsh_10 ===\n")
print(matrix(c(val_tp, val_fn, val_fp, val_tn), nrow = 2, byrow = TRUE,
             dimnames = list(c("Actual Positive", "Actual Negative"),
                             c("Predicted Positive", "Predicted Negative"))))

klsh_10_metrics$f1_score <- with(klsh_10_metrics,
                                 2*precision*recall/(precision + recall))

eval_metrics$klsh_10 <- unlist(klsh_10_metrics)

blocks_klsh_100 <- klsh::klsh(
  r.set = RLdata500[, c("fname_c1", "fname_c2", "lname_c1",
                        "lname_c2", "by", "bm", "bd")],
  p = 20, num.blocks = 100, k = 2)

klsh_100_metrics <- klsh::confusion.from.blocking(
  blocking = blocks_klsh_100,
  true_ids = RLdata500$ent_id)[-1]

c_rec <- klsh_100_metrics$recall
c_prec <- klsh_100_metrics$precision

val_tp <- round(c_rec * n_pairs_true)
val_fn <- n_pairs_true - val_tp
val_fp <- if(c_prec == 0) 0 else round(val_tp * (1/c_prec - 1))
val_tn <- n_pairs_all - (val_tp + val_fp + val_fn)

cat("\n=== Confusion Matrix: klsh_100 ===\n")
print(matrix(c(val_tp, val_fn, val_fp, val_tn), nrow = 2, byrow = TRUE,
             dimnames = list(c("Actual Positive", "Actual Negative"),
                             c("Predicted Positive", "Predicted Negative"))))

klsh_100_metrics$f1_score <- with(klsh_100_metrics,
                                  2*precision*recall/(precision + recall))

eval_metrics$klsh_100 <- unlist(klsh_100_metrics)

round(do.call(rbind, eval_metrics) * 100, 2)[, c("precision", "fpr", "fnr", "accuracy", "f1_score")] |> kable(digits=2)
